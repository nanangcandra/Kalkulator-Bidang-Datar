package com.example.KalkulatorBidangDatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Lingkaran extends AppCompatActivity {

    private EditText pi;
    private EditText r;
    private TextView result_luas;
    private TextView result_keliling;
    private static final String TAG = "Lingkaran";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lingkaran);

        //initialize
        pi = (EditText) findViewById(R.id.pi);
        r = (EditText) findViewById(R.id.r);
        result_luas = (TextView) findViewById(R.id.result_luas);
        result_keliling = (TextView)
                findViewById(R.id.result_keliling);
    }

    public void result(View view) {
        double pi, r;
        try {
            pi = getOperand(this.pi);
            r = getOperand(this.r);
        }
        catch (NumberFormatException e) {
            Log.d(TAG, "Error format..." + e);
            result_luas.setVisibility(View.VISIBLE);
            result_keliling.setVisibility(View.INVISIBLE);
            result_luas.setText(getString(R.string.computationError));
            return;
        }

        String luas, keliling;
        luas = String.valueOf(pi * r * r);
        keliling = String.valueOf(2 * pi * r);

        result_luas.setVisibility(View.VISIBLE);
        result_keliling.setVisibility(View.VISIBLE);
        result_luas.setText("Luas: " + luas);
        result_keliling.setText("Keliling: " + keliling);
    }

    private static Double getOperand(EditText operandEditText) {
        String operandText = operandEditText.getText().toString();
        return Double.valueOf(operandText);
    }
}
