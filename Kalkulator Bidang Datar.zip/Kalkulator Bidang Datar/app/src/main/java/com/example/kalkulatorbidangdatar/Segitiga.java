package com.example.KalkulatorBidangDatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Segitiga extends AppCompatActivity {

    private EditText alas;
    private EditText tinggi;
    private EditText miring;
    private TextView result_luas;
    private TextView result_keliling;
    private static final String TAG = "Segitiga";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segitiga);

        //initialize
        alas = (EditText) findViewById(R.id.alas);
        tinggi = (EditText) findViewById(R.id.tinggi);
        miring = (EditText) findViewById(R.id.miring);
        result_luas = (TextView) findViewById(R.id.result_luas);
        result_keliling = (TextView)
                findViewById(R.id.result_keliling);
    }

    public void result(View view) {
        double alas, tinggi, miring;
        try {
            alas = getOperand(this.alas);
            tinggi = getOperand(this.tinggi);
            miring = getOperand(this.miring);
        }
        catch (NumberFormatException e) {
            Log.d(TAG, "Error format..." + e);
            result_luas.setVisibility(View.VISIBLE);
            result_keliling.setVisibility(View.INVISIBLE);
            result_luas.setText(getString(R.string.computationError));
            return;
        }

        String luas, keliling;
        luas = String.valueOf((alas * tinggi) / 2);
        keliling = String.valueOf(alas + tinggi + miring);

        result_luas.setVisibility(View.VISIBLE);
        result_keliling.setVisibility(View.VISIBLE);
        result_luas.setText("Luas: " + luas);
        result_keliling.setText("Keliling: " + keliling);
    }

    private static Double getOperand(EditText operandEditText) {
        String operandText = operandEditText.getText().toString();
        return Double.valueOf(operandText);
    }
}
